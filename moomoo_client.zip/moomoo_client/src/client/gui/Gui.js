import GuiNode from "../gui/GuiNode.js"

export default class Gui {
    constructor() {
        this.gameUI = new GuiNode("#game_ui")
    }
}