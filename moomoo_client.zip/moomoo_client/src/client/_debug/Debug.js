import SocketDebug from "./SocketDebug.js"

export default class Debug {
    static socket = new SocketDebug()

    constructor() {}
}