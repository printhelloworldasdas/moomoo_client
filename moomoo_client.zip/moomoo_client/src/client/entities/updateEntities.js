import Player from "./player/Player.js"

export default function updateEntities() {
    Player.updatePlayers()
}